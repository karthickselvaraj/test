package com.jpmchase.datapipeline.coordinator.model;

import com.jpmchase.datapipeline.coordinator.model.ExecutionPlan;

import java.util.Map;
import java.util.UUID;

public class PipelineRun {
    private UUID pipelineRunId;
    private String pipelineName;
    private String environment;
    private Map<String, Object> globalVariables; // Global variable context
    private ExecutionPlan executionPlan;         // Pipeline blueprint
    private String status;                       // e.g., "PENDING", "RUNNING", "COMPLETED", "FAILED"

    // Constructors, Getters, and Setters
    public PipelineRun(String pipelineName, String environment, Map<String, Object> globalVariables, ExecutionPlan executionPlan) {
        this.pipelineRunId = UUID.randomUUID();
        this.pipelineName = pipelineName;
        this.environment = environment;
        this.globalVariables = globalVariables;
        this.executionPlan = executionPlan;
        this.status = "PENDING";
    }

    public UUID getPipelineRunId() {
        return pipelineRunId;
    }

    public String getPipelineName() {
        return pipelineName;
    }

    public String getEnvironment() {
        return environment;
    }

    public Map<String, Object> getGlobalVariables() {
        return globalVariables;
    }

    public ExecutionPlan getExecutionPlan() {
        return executionPlan;
    }

    public String getStatus() {
        return status;
    }

    public void setGlobalVariables(Map<String, Object> globalVariables) {
        this.globalVariables = globalVariables;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

