package com.jpmchase.datapipeline.coordinator.core.utils;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;

@Component
public class YamlMerger {

    private final Yaml yaml;

    public YamlMerger() {
        this.yaml = new Yaml(new SafeConstructor(new LoaderOptions()));
    }

    public Map<String, Object> mergeYamlFiles(File commonFile, File envFile) throws IOException {
        Map<String, Object> commonData = null;
        Map<String, Object> envData = null;

        if (commonFile != null) {
            try (FileInputStream fis = new FileInputStream(commonFile)) {
                commonData = yaml.load(fis);
            }
        }

        if (envFile != null) {
            try (FileInputStream fis = new FileInputStream(envFile)) {
                envData = yaml.load(fis);
            }
        }

        return mergeMaps(commonData, envData);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> mergeMaps(Map<String, Object> commonData, Map<String, Object> envData) {
        if (commonData == null) {
            return envData;
        }
        if (envData == null) {
            return commonData;
        }

        for (Map.Entry<String, Object> entry : envData.entrySet()) {
            String key = entry.getKey();
            Object envValue = entry.getValue();
            Object commonValue = commonData.get(key);

            if (envValue instanceof Map && commonValue instanceof Map) {
                // Recursive merge
                Map<String, Object> mergedSubMap = mergeMaps((Map<String, Object>) commonValue, (Map<String, Object>) envValue);
                commonData.put(key, mergedSubMap);
            } else {
                // Override with env-specific value
                commonData.put(key, envValue);
            }
        }
        return commonData;
    }

    public static String convertMapToYaml(Map<String, Object> data) {
        // Configure DumperOptions for better formatting
        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK); // Use block style
        options.setPrettyFlow(true);
        options.setIndent(2);

        Yaml yaml = new Yaml(options);
        return yaml.dump(data);
    }

    public Map<String, Object> convertYamlToMap(File yamlFile) throws IOException {
        Map<String, Object> yamlData = null;
        if (yamlFile != null) {
            try (FileInputStream fis = new FileInputStream(yamlFile)) {
                yamlData = yaml.load(fis);
            }
        }
        return yamlData;
    }

}

