package com.jpmchase.datapipeline.coordinator.core.processor;

import com.jpmchase.datapipeline.coordinator.core.loader.*;
import com.jpmchase.datapipeline.coordinator.model.*;
import com.jpmchase.datapipeline.coordinator.core.utils.VariableReplacer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
public class PipelineProcessorImpl implements PipelineProcessor {

    private final PipelineLoader pipelineLoader;
    private final StageLoader stageLoader;
    private final VariablesLoader variablesLoader;
    private final ModelLoader modelLoader;

    @Autowired
    public PipelineProcessorImpl(PipelineLoader pipelineLoader, StageLoader stageLoader,
                                 VariablesLoader variablesLoader, ModelLoader modelLoader) {
        this.pipelineLoader = pipelineLoader;
        this.stageLoader = stageLoader;
        this.variablesLoader = variablesLoader;
        this.modelLoader = modelLoader;
    }

    @Override
    public ExecutionPlan buildExecutionPlan(PipelineContext pipelineContext) throws IOException {

        // Step 1: Load initial variables
        Map<String, Object> variables = variablesLoader.load("variable", pipelineContext);
        System.out.println("Variables loaded: " + variables);

        // Step 2: Load pipeline configuration
        Map<String, Object> pipelineData = pipelineLoader.load(pipelineContext.getPipelineName(), pipelineContext);
        Map<String, Object> pipeline = (Map<String, Object>) pipelineData.get("pipeline");
        List<String> stageNames = (List<String>) pipeline.get("stages");

        List<ExecutionStage> executionStages = new ArrayList<>();
        int sequenceNumber = 1;

        for (String stageName : stageNames) {
            // Load stage configuration
            Map<String, Object> stageData = stageLoader.load(stageName, pipelineContext);
            Map<String, Object> stageConfig = (Map<String, Object>) stageData.get("stage");

            // Build ExecutionStage
            ExecutionStage executionStage = new ExecutionStage(sequenceNumber++, stageName);
            executionStage.setDescription((String) stageConfig.get("description"));

            // Handle stage-specific variables
            Map<String, Object> stageVariables = (Map<String, Object>) stageConfig.get("variables");
            Map<String, Object> combinedVariables = new HashMap<>(variables);
            if (stageVariables != null) {
                combinedVariables.putAll(stageVariables);
            }

            // Load and prepare SQL query
            String sqlModelName = (String) stageConfig.get("sql_model");
            String sqlModelContent = null;
            if (sqlModelName != null) {
                sqlModelContent = modelLoader.load(sqlModelName, pipelineContext);
            }

            // Store the original template
            executionStage.setSqlQueryTemplate(sqlModelContent);

            // Attempt variable substitution (allow unresolved variables)
            String resolvedSql = VariableReplacer.replaceVariables(sqlModelContent, combinedVariables, true);
            executionStage.setSqlQueryResolved(resolvedSql);

            // Set databases (with variable substitution)
            String sourceDatabase = VariableReplacer.replaceVariables((String) stageConfig.get("source_database"), combinedVariables, true);
            String targetDatabase = VariableReplacer.replaceVariables((String) stageConfig.get("target_database"), combinedVariables, true);
            executionStage.setSourceDatabase(sourceDatabase);
            executionStage.setTargetDatabase(targetDatabase);

            // Handle tests
            List<Map<String, Object>> testsConfig = (List<Map<String, Object>>) stageConfig.get("tests");
            if (testsConfig != null) {
                List<Test> tests = new ArrayList<>();
                for (Map<String, Object> testConfig : testsConfig) {
                    String testName = (String) testConfig.get("name");
                    String sqlTest = (String) testConfig.get("sql_test");
                    String resolvedSqlTest = VariableReplacer.replaceVariables(sqlTest, combinedVariables, true);
                    tests.add(new Test(testName, resolvedSqlTest));
                }
                executionStage.setTests(tests);
            }

            // Handle output variables
            List<Map<String, Object>> outputVariablesConfig = (List<Map<String, Object>>) stageConfig.get("output_variables");
            if (outputVariablesConfig != null) {
                List<OutputVariable> outputVariables = new ArrayList<>();
                for (Map<String, Object> outputVarConfig : outputVariablesConfig) {
                    String name = (String) outputVarConfig.get("name");
                    String description = (String) outputVarConfig.get("description");
                    String query = (String) outputVarConfig.get("query");
                    String format = (String) outputVarConfig.get("format");
                    String resolvedQuery = VariableReplacer.replaceVariables(query, combinedVariables, true);
                    outputVariables.add(new OutputVariable(name, description, resolvedQuery, format));
                }
                executionStage.setOutputVariables(outputVariables);
            }

            // Handle output variable assignments
            Map<String, String> outputVariableAssignmentsConfig = (Map<String, String>) stageConfig.get("output_variable_assignment");
            if (outputVariableAssignmentsConfig != null) {
                List<OutputVariableAssignment> outputVariableAssignments = new ArrayList<>();
                for (Map.Entry<String, String> entry : outputVariableAssignmentsConfig.entrySet()) {
                    String globalVarName = entry.getKey();
                    String outputVarName = entry.getValue();
                    outputVariableAssignments.add(new OutputVariableAssignment(globalVarName, outputVarName));
                }
                executionStage.setOutputVariableAssignments(outputVariableAssignments);
            }

            // Add the execution stage to the list
            executionStages.add(executionStage);
        }

        // Build ExecutionPlan
        ExecutionPlan executionPlan = new ExecutionPlan(variables, executionStages);
        return executionPlan;
    }
}
