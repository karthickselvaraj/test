package com.jpmchase.datapipeline.coordinator.core.loader;

import com.jpmchase.datapipeline.coordinator.core.utils.ProjectFileBrowser;
import com.jpmchase.datapipeline.coordinator.core.utils.YamlMerger;
import com.jpmchase.datapipeline.coordinator.model.PipelineContext;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;

public abstract class AbstractConfigLoader<T> implements ConfigLoader<T> {
    @Autowired
    protected ProjectFileBrowser fileBrowser;

    @Autowired
    protected YamlMerger yamlMerger;

    /**
     * Template method for loading configurations.
     *
     * @param name        The name of the configuration to load.
     * @param pipelineContext Contains pipelineName, location, environment (e.g., "dev", "prod").
     * @return The loaded configuration object.
     * @throws IOException If an error occurs during loading.
     */
    public final T load(String name, PipelineContext pipelineContext) throws IOException {
        // Step 1: Get file pair (common and environment-specific files)
        ProjectFileBrowser.FilePair filePair = getFilePair(name, pipelineContext);

        // Step 2: Load and merge configurations
        T mergedConfig = loadAndMergeConfigurations(filePair);

        // Step 3: Post-processing (if any)
        postProcess(mergedConfig);

        return mergedConfig;
    }

    /**
     * Gets the file pair for the configuration.
     *
     * @param name        The name of the configuration.
     * @param pipelineContext The environment.
     * @return The file pair containing common and environment-specific files.
     * @throws IOException If an error occurs.
     */
    protected abstract ProjectFileBrowser.FilePair getFilePair(String name, PipelineContext pipelineContext) throws IOException;

    /**
     * Loads and merges configurations from the file pair.
     *
     * @param filePair The file pair.
     * @return The merged configuration object.
     * @throws IOException If an error occurs.
     */
    protected abstract T loadAndMergeConfigurations(ProjectFileBrowser.FilePair filePair) throws IOException;

    /**
     * Post-processes the loaded configuration (optional).
     *
     * @param config The configuration object.
     */
    protected void postProcess(T config) {
        // Default implementation: do nothing
    }
}
