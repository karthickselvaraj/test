package com.jpmchase.datapipeline.coordinator.model;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class ExecutionPlan {
    private Map<String, Object> variables; // Global variable context
    private List<ExecutionStage> stages;   // Sequence of stages

    public ExecutionPlan(Map<String, Object> variables, List<ExecutionStage> stages) {
        this.variables = variables;
        this.stages = stages;
    }

    // Getters and Setters
    public Map<String, Object> getVariables() {
        return variables;
    }

    public void setVariables(Map<String, Object> variables) {
        this.variables = variables;
    }

    public List<ExecutionStage> getStages() {
        return stages;
    }

    public void setStages(List<ExecutionStage> stages) {
        this.stages = stages;
    }
}

