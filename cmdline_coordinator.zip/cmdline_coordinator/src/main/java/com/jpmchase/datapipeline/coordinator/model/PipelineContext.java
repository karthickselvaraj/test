package com.jpmchase.datapipeline.coordinator.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PipelineContext {
    private String projectLocation;
    private String environment;
    private String projectKey;
    private String repoName;
    private String pipelineName;
}
