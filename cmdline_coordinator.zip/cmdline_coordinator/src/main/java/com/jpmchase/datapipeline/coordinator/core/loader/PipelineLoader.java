package com.jpmchase.datapipeline.coordinator.core.loader;

import com.jpmchase.datapipeline.coordinator.core.utils.ProjectFileBrowser;
import com.jpmchase.datapipeline.coordinator.core.utils.ProjectFileBrowser.FilePair;
import com.jpmchase.datapipeline.coordinator.model.PipelineContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Map;

@Component
public class PipelineLoader extends AbstractConfigLoader<Map<String,Object>> {


    @Override
    protected FilePair getFilePair(String pipelineName, PipelineContext pipelineContext) throws IOException {
        //ignore environment as we dont support env folder under pipelines
        Path pipelineFilePath = fileBrowser.getPipelineFile(Paths.get(pipelineContext.getProjectLocation()),
                pipelineContext.getPipelineName());
        FilePair filePair = new FilePair(pipelineFilePath.toFile(), null);
        return filePair;
    }

    @Override
    protected Map<String, Object> loadAndMergeConfigurations(FilePair filePair) throws IOException {
        try {
            Path pipelineFile = filePair.getCommonFile().toPath();
            Map<String, Object> pipelineData = yamlMerger.convertYamlToMap(pipelineFile.toFile());
            if (pipelineData == null) {
                throw new IOException("Pipeline file not found: " + pipelineFile.toString());
            }
            return pipelineData;
        }catch (Exception e) {
            // TODO: print file not found or content is empty
        }
        return Collections.emptyMap();
    }
}
