package com.jpmchase.datapipeline.coordinator.model;

import com.jpmchase.datapipeline.coordinator.model.ExecutionStage;
import com.jpmchase.datapipeline.coordinator.model.OutputVariable;
import com.jpmchase.datapipeline.coordinator.model.StageRun;
import com.jpmchase.datapipeline.coordinator.model.Test;
import lombok.Data;

import java.util.List;

@Data
public class RunnableStage {
    private String stageRunId;
    private String stageName;
    private String sourceDatabase;
    private String targetDatabase;
    private String sqlQuery; // May contain unresolved variables
    private List<Test> tests;
    private List<OutputVariable> outputVariables;

    public RunnableStage(StageRun stageRun) {
        this.stageRunId = stageRun.getStageRunId().toString();
        ExecutionStage stage = stageRun.getStage();
        this.stageName = stage.getStageName();
        this.sourceDatabase = stage.getSourceDatabase();
        this.targetDatabase = stage.getTargetDatabase();
        this.sqlQuery = stage.getSqlQueryResolved();
        this.tests = stage.getTests();
        this.outputVariables = stage.getOutputVariables();
    }
}
