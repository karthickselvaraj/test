package com.jpmchase.datapipeline.coordinator.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class OutputVariableAssignment {
    // Name of the variable in the global context
    private String globalVariableName;

    // Name of the output variable from the stage
    private String outputVariableName;
}

