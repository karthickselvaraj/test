package com.jpmchase.datapipeline.coordinator.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OutputVariable {
    private String name;
    private String description;
    private String query; // Query to fetch the output variable after variable substitution
    private String format; // e.g., "json"
}
