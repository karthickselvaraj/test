package com.jpmchase.datapipeline.coordinator.core.utils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

@Component
public class ProjectFileBrowser {

    public ProjectFileBrowser() {
    }

    public FilePair getVariablesFilePair(Path basePath, String environment) {
        return getFilePair(basePath,"variables", "variables.yaml", environment);
    }

    public FilePair getModelFilePair(Path basePath, String modelName, String environment) {
        return getFilePair(basePath, "models", modelName, environment);
    }

    public FilePair getStageFilePair(Path basePath, String stageName, String environment) {
        return getFilePair(basePath, "stages", stageName + ".yaml", environment);
    }

    public Path getPipelineFile(Path basePath, String pipelineName) {
        Path pipelinePath = basePath.resolve(Paths.get("pipelines", pipelineName+".yaml"));
        return pipelinePath;
    }

    private FilePair getFilePair(Path basePath, String folder, String fileName, String environment) {
        // Environment-specific file
        Path envFilePath = basePath.resolve(Paths.get(folder, "env/" + environment, fileName));
        File envFile = Files.exists(envFilePath) && Files.isRegularFile(envFilePath) ? envFilePath.toFile() : null;

        // Common file
        Path commonFilePath = basePath.resolve(Paths.get(folder, "common", fileName));
        File commonFile = Files.exists(commonFilePath) && Files.isRegularFile(commonFilePath) ? commonFilePath.toFile() : null;

        return new FilePair(commonFile, envFile);
    }

    public static class FilePair {
        private final File commonFile;
        private final File envFile;

        public FilePair(File commonFile, File envFile) {
            this.commonFile = commonFile;
            this.envFile = envFile;
        }

        public File getCommonFile() {
            return commonFile;
        }

        public File getEnvFile() {
            return envFile;
        }
    }
}

