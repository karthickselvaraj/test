package com.jpmchase.datapipeline.coordinator.model;

import com.jpmchase.datapipeline.coordinator.model.ExecutionStage;

import java.util.Map;
import java.util.UUID;

public class StageRun {
    private UUID stageRunId;
    private UUID pipelineRunId;
    private int sequenceNumber;
    private String stageName;
    private ExecutionStage stage;
    private String status; // e.g., "PENDING", "RUNNING", "COMPLETED", "FAILED"
    private Map<String, Object> outputVariables;

    public StageRun(UUID pipelineRunId, int sequenceNumber, String stageName, ExecutionStage stage) {
        this.stageRunId = UUID.randomUUID();
        this.pipelineRunId = pipelineRunId;
        this.sequenceNumber = sequenceNumber;
        this.stageName = stageName;
        this.stage = stage;
        this.status = "PENDING";
    }

    public UUID getStageRunId() {
        return stageRunId;
    }

    public UUID getPipelineRunId() {
        return pipelineRunId;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }

    public String getStageName() {
        return stageName;
    }

    public ExecutionStage getStage() {
        return stage;
    }

    public String getStatus() {
        return status;
    }

    public Map<String, Object> getOutputVariables() {
        return outputVariables;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setOutputVariables(Map<String, Object> outputVariables) {
        this.outputVariables = outputVariables;
    }
}

