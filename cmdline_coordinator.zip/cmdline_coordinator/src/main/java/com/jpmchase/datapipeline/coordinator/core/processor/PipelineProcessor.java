package com.jpmchase.datapipeline.coordinator.core.processor;

import com.jpmchase.datapipeline.coordinator.model.ExecutionPlan;
import com.jpmchase.datapipeline.coordinator.model.PipelineContext;

import java.io.IOException;

public interface PipelineProcessor {
    ExecutionPlan buildExecutionPlan(PipelineContext pipelineContext) throws IOException;
}
