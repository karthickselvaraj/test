package com.jpmchase.datapipeline.coordinator.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExecutionStage {
    private int sequenceNumber;
    private String stageName;
    private String description;
    private String sourceDatabase;
    private String targetDatabase;
    private String sqlQueryTemplate; // SQL query with variable placeholders
    private String sqlQueryResolved; // Resolved SQL query (may contain unresolved variables)
    private List<Test> tests;
    private List<OutputVariable> outputVariables;
    private List<OutputVariableAssignment> outputVariableAssignments;

    // Constructors, Getters, and Setters

    public ExecutionStage(int sequenceNumber, String stageName) {
        this.sequenceNumber = sequenceNumber;
        this.stageName = stageName;
    }
}