//package com.jpmchase.datapipeline.coordinator;
//
//package com.example.datapipeline.service;
//
//import com.example.datapipeline.executor.StageExecutor;
//import com.example.datapipeline.model.*;
//import com.example.datapipeline.processor.PipelineProcessor;
//import com.example.datapipeline.repository.PipelineRunRepository;
//import com.example.datapipeline.repository.StageRunRepository;
//import com.example.datapipeline.util.VariableReplacer;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.*;
//
//@Service
//public class DataPipelineService {
//
//    private final PipelineProcessor pipelineProcessor;
//    private final StageExecutor stageExecutor;
//    private final PipelineRunRepository pipelineRunRepository;
//    private final StageRunRepository stageRunRepository;
//
//    @Autowired
//    public DataPipelineService(PipelineProcessor pipelineProcessor,
//                               StageExecutor stageExecutor,
//                               PipelineRunRepository pipelineRunRepository,
//                               StageRunRepository stageRunRepository) {
//        this.pipelineProcessor = pipelineProcessor;
//        this.stageExecutor = stageExecutor;
//        this.pipelineRunRepository = pipelineRunRepository;
//        this.stageRunRepository = stageRunRepository;
//    }
//
//    /**
//     * Starts a pipeline run by building the execution plan, initializing the pipeline run,
//     * and storing the plan and stages.
//     *
//     * @param pipelineName The name of the pipeline.
//     * @param environment  The execution environment.
//     * @return The UUID of the created PipelineRun.
//     */
//    public UUID startPipelineRun(String pipelineName, String environment) {
//        try {
//            // Build the execution plan (pipeline blueprint)
//            ExecutionPlan executionPlan = pipelineProcessor.buildExecutionPlan(pipelineName, environment);
//
//            // Initialize PipelineRun with the execution plan and initial global variables
//            PipelineRun pipelineRun = new PipelineRun(pipelineName, environment, executionPlan.getVariables(), executionPlan);
//            pipelineRunRepository.save(pipelineRun);
//
//            // Initialize StageRuns for each stage in the execution plan
//            for (ExecutionStage stage : executionPlan.getStages()) {
//                StageRun stageRun = new StageRun(pipelineRun.getPipelineRunId(), stage.getSequenceNumber(), stage.getStageName(), stage);
//                stageRunRepository.save(stageRun);
//            }
//
//            return pipelineRun.getPipelineRunId();
//
//        } catch (Exception e) {
//            // Handle exceptions appropriately
//            e.printStackTrace();
//            return null;
//        }
//    }
//
//    /**
//     * Prepares a stage for execution by resolving variables with the current global variable context.
//     *
//     * @param pipelineRunId The UUID of the pipeline run.
//     * @param stageRunId    The UUID of the stage run.
//     * @return A RunnableStage object ready for execution.
//     */
//    public RunnableStage prepareStageForExecution(UUID pipelineRunId, UUID stageRunId) {
//        PipelineRun pipelineRun = pipelineRunRepository.findById(pipelineRunId);
//        StageRun stageRun = stageRunRepository.findById(stageRunId);
//        Map<String, Object> globalVariables = pipelineRun.getGlobalVariables();
//        ExecutionStage stage = stageRun.getStage();
//
//        // Perform variable substitution with updated global variables
//        String resolvedSql = VariableReplacer.replaceVariables(stage.getSqlQueryTemplate(), globalVariables, true);
//        stage.setSqlQueryResolved(resolvedSql);
//
//        // Resolve source and target databases
//        String resolvedSourceDatabase = VariableReplacer.replaceVariables(stage.getSourceDatabase(), globalVariables, true);
//        String resolvedTargetDatabase = VariableReplacer.replaceVariables(stage.getTargetDatabase(), globalVariables, true);
//        stage.setSourceDatabase(resolvedSourceDatabase);
//        stage.setTargetDatabase(resolvedTargetDatabase);
//
//        // Resolve tests
//        if (stage.getTests() != null) {
//            for (Test test : stage.getTests()) {
//                String resolvedSqlTest = VariableReplacer.replaceVariables(test.getSqlTest(), globalVariables, true);
//                test.setSqlTest(resolvedSqlTest);
//            }
//        }
//
//        // Resolve output variable queries
//        if (stage.getOutputVariables() != null) {
//            for (OutputVariable outputVar : stage.getOutputVariables()) {
//                String resolvedQuery = VariableReplacer.replaceVariables(outputVar.getQuery(), globalVariables, true);
//                outputVar.setQuery(resolvedQuery);
//            }
//        }
//
//        // Update the stage in the StageRun
//        stageRun.setStage(stage);
//        stageRunRepository.save(stageRun);
//
//        // Create RunnableStage
//        RunnableStage runnableStage = new RunnableStage(stageRun);
//
//        return runnableStage;
//    }
//
//    /**
//     * Updates the pipeline run and stage run with the results of a stage execution.
//     *
//     * @param pipelineRunId The UUID of the pipeline run.
//     * @param stageRunId    The UUID of the stage run.
//     * @param stageResult   The result of the stage execution.
//     */
//    public void updatePipelineRunWithStageResult(UUID pipelineRunId, UUID stageRunId, StageResult stageResult) {
//        PipelineRun pipelineRun = pipelineRunRepository.findById(pipelineRunId);
//        StageRun stageRun = stageRunRepository.findById(stageRunId);
//
//        if (stageResult.isSuccess()) {
//            // Update global variables with output variables
//            Map<String, Object> globalVariables = pipelineRun.getGlobalVariables();
//            ExecutionStage stage = stageRun.getStage();
//
//            if (stageResult.getOutputVariables() != null && stage.getOutputVariableAssignments() != null) {
//                for (OutputVariableAssignment assignment : stage.getOutputVariableAssignments()) {
//                    String globalVarName = assignment.getGlobalVariableName();
//                    String outputVarName = assignment.getOutputVariableName();
//                    Object value = stageResult.getOutputVariables().get(outputVarName);
//                    if (value != null) {
//                        globalVariables.put(globalVarName, value);
//                    }
//                }
//            }
//            pipelineRun.setGlobalVariables(globalVariables);
//
//            // Update stage run status and output variables
//            stageRun.setStatus("COMPLETED");
//            stageRun.setOutputVariables(stageResult.getOutputVariables());
//            stageRunRepository.save(stageRun);
//
//            // Update pipeline run status if all stages are completed
//            List<StageRun> stageRuns = stageRunRepository.findByPipelineRunId(pipelineRunId);
//            boolean allCompleted = stageRuns.stream().allMatch(sr -> sr.getStatus().equals("COMPLETED"));
//            if (allCompleted) {
//                pipelineRun.setStatus("COMPLETED");
//            } else {
//                pipelineRun.setStatus("RUNNING");
//            }
//            pipelineRunRepository.save(pipelineRun);
//
//        } else {
//            // Handle stage failure
//            stageRun.setStatus("FAILED");
//            stageRunRepository.save(stageRun);
//            pipelineRun.setStatus("FAILED");
//            pipelineRunRepository.save(pipelineRun);
//        }
//    }
//
//    /**
//     * Executes the pipeline by sequentially executing its stages.
//     *
//     * @param pipelineRunId The UUID of the pipeline run.
//     */
//    public void executePipeline(UUID pipelineRunId) {
//        PipelineRun pipelineRun = pipelineRunRepository.findById(pipelineRunId);
//        Map<String, Object> globalVariables = pipelineRun.getGlobalVariables();
//
//        // Get the stages in sequence order
//        List<StageRun> stageRuns = stageRunRepository.findByPipelineRunId(pipelineRunId);
//        stageRuns.sort(Comparator.comparingInt(StageRun::getSequenceNumber));
//
//        // Set pipeline status to RUNNING
//        pipelineRun.setStatus("RUNNING");
//        pipelineRunRepository.save(pipelineRun);
//
//        for (StageRun stageRun : stageRuns) {
//            if (!stageRun.getStatus().equals("PENDING")) {
//                // Skip stages that are already completed or failed
//                continue;
//            }
//
//            // Prepare the stage for execution
//            RunnableStage runnableStage = prepareStageForExecution(pipelineRunId, stageRun.getStageRunId());
//
//            // Execute the stage
//            StageResult stageResult = stageExecutor.executeStage(runnableStage);
//
//            // Update pipeline run with stage result
//            updatePipelineRunWithStageResult(pipelineRunId, stageRun.getStageRunId(), stageResult);
//
//            if (!stageResult.isSuccess()) {
//                // Stop execution if a stage fails
//                break;
//            }
//        }
//    }
//}