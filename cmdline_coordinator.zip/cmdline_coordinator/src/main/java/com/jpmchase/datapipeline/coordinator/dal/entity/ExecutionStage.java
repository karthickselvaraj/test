package com.jpmchase.datapipeline.coordinator.dal.entity;

package com.example.datapipeline.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "execution_stage")
public class ExecutionStage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int sequenceNumber;
    private String stageName;
    private String description;
    private String sourceDatabase;
    private String targetDatabase;
    private String sqlQueryTemplate;
    private String sqlQueryResolved;

    @OneToMany(mappedBy = "executionStage", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Test> tests = new ArrayList<>();

    @OneToMany(mappedBy = "executionStage", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OutputVariable> outputVariables = new ArrayList<>();

    @OneToMany(mappedBy = "executionStage", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OutputVariableAssignment> outputVariableAssignments = new ArrayList<>();

    // Constructors
    public ExecutionStage() {}

    public ExecutionStage(int sequenceNumber, String stageName) {
        this.sequenceNumber = sequenceNumber;
        this.stageName = stageName;
    }

    // Getters and Setters
    // (Include getters and setters for all fields)

    // Helper methods to manage bidirectional relationships
    public void addTest(Test test) {
        tests.add(test);
        test.setExecutionStage(this);
    }

    public void removeTest(Test test) {
        tests.remove(test);
        test.setExecutionStage(null);
    }

    public void addOutputVariable(OutputVariable outputVariable) {
        outputVariables.add(outputVariable);
        outputVariable.setExecutionStage(this);
    }

    public void removeOutputVariable(OutputVariable outputVariable) {
        outputVariables.remove(outputVariable);
        outputVariable.setExecutionStage(null);
    }

    public void addOutputVariableAssignment(OutputVariableAssignment assignment) {
        outputVariableAssignments.add(assignment);
        assignment.setExecutionStage(this);
    }

    public void removeOutputVariableAssignment(OutputVariableAssignment assignment) {
        outputVariableAssignments.remove(assignment);
        assignment.setExecutionStage(null);
    }

    // Getters and setters for id, sequenceNumber, stageName, description, sourceDatabase, targetDatabase, sqlQueryTemplate, sqlQueryResolved
    // Getters and setters for tests, outputVariables, outputVariableAssignments
}

