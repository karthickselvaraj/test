package com.jpmchase.datapipeline.coordinator.core.loader;

import com.jpmchase.datapipeline.coordinator.model.PipelineContext;

import java.io.IOException;

public interface ConfigLoader<T> {
    T load(String name, PipelineContext pipelineContext) throws IOException;
}
