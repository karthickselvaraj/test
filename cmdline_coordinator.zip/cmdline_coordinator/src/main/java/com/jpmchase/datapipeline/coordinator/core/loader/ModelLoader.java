package com.jpmchase.datapipeline.coordinator.core.loader;

import com.jpmchase.datapipeline.coordinator.core.utils.ProjectFileBrowser;
import com.jpmchase.datapipeline.coordinator.model.PipelineContext;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

@Component
public class ModelLoader extends AbstractConfigLoader<String>{
    @Override
    protected ProjectFileBrowser.FilePair getFilePair(String modelName, PipelineContext pipelineContext) {
        //TODO: Check the file pair is correctly representing a valid file otherwise
        // log the statement
        return fileBrowser.getModelFilePair(Paths.get(pipelineContext.getProjectLocation()),
                modelName, pipelineContext.getEnvironment());
    }

    @Override
    protected String loadAndMergeConfigurations(ProjectFileBrowser.FilePair filePair) {
        try {
            return loadModel(filePair);
        } catch (IOException e) {
            //TODO: Log the error
            return null;
        }
    }

    private String loadModel(ProjectFileBrowser.FilePair modelFiles) throws IOException {
        File modelFile = modelFiles.getEnvFile() != null ? modelFiles.getEnvFile() : modelFiles.getCommonFile();

        if (modelFile == null) {
            throw new IOException("Model file not found for model: " + modelFile.getAbsoluteFile().toString());
        }

        String sqlContent = new String(Files.readAllBytes(modelFile.toPath()));

        // Remove SQL comments from the content
        String cleanedSql = removeSqlComments(sqlContent);

        return cleanedSql.trim();
    }

    private String removeSqlComments(String sqlContent) {
        StringBuilder result = new StringBuilder();
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;
        boolean inLineComment = false;
        boolean inBlockComment = false;

        for (int i = 0; i < sqlContent.length(); i++) {
            char c = sqlContent.charAt(i);
            char nextChar = i + 1 < sqlContent.length() ? sqlContent.charAt(i + 1) : '\0';

            if (inLineComment) {
                if (c == '\n' || c == '\r') {
                    inLineComment = false;
                    result.append(c);
                }
                // Skip characters inside line comment
            } else if (inBlockComment) {
                if (c == '*' && nextChar == '/') {
                    inBlockComment = false;
                    i++; // Skip '/'
                }
                // Skip characters inside block comment
            } else if (inSingleQuote) {
                result.append(c);
                if (c == '\'' && sqlContent.charAt(i - 1) != '\\') {
                    inSingleQuote = false;
                }
            } else if (inDoubleQuote) {
                result.append(c);
                if (c == '"' && sqlContent.charAt(i - 1) != '\\') {
                    inDoubleQuote = false;
                }
            } else {
                if (c == '-' && nextChar == '-') {
                    inLineComment = true;
                    i++; // Skip '-'
                } else if (c == '/' && nextChar == '*') {
                    inBlockComment = true;
                    i++; // Skip '*'
                } else if (c == '\'') {
                    inSingleQuote = true;
                    result.append(c);
                } else if (c == '"') {
                    inDoubleQuote = true;
                    result.append(c);
                } else {
                    result.append(c);
                }
            }
        }

        return result.toString();
    }
}

