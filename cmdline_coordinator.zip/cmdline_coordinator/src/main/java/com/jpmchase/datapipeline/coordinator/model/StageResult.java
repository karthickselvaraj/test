package com.jpmchase.datapipeline.coordinator.model;

import java.util.Map;

public class StageResult {
    private String stageName;
    private boolean success;
    private String message; // Error message if any
    private Map<String, Object> outputVariables; // Output variables and their values

    // Constructors, Getters, and Setters
    public StageResult(String stageName, boolean success, String message, Map<String, Object> outputVariables) {
        this.stageName = stageName;
        this.success = success;
        this.message = message;
        this.outputVariables = outputVariables;
    }

    public String getStageName() {
        return stageName;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public Map<String, Object> getOutputVariables() {
        return outputVariables;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setOutputVariables(Map<String, Object> outputVariables) {
        this.outputVariables = outputVariables;
    }
}
