package com.jpmchase.datapipeline.coordinator.core.loader;

import com.jpmchase.datapipeline.coordinator.core.utils.ProjectFileBrowser;
import com.jpmchase.datapipeline.coordinator.core.utils.YamlMerger;
import com.jpmchase.datapipeline.coordinator.model.PipelineContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

/**
 * This class loads variables based on the env and that overrides the variables
 * declared in the common.
 */
@Component
public class VariablesLoader extends AbstractConfigLoader<Map<String, Object>> {

    @Override
    protected ProjectFileBrowser.FilePair getFilePair(String name, PipelineContext pipelineContext) throws IOException {
        return fileBrowser.getVariablesFilePair(Paths.get(pipelineContext.getProjectLocation()), pipelineContext.getEnvironment());
    }

    @Override
    protected Map<String, Object> loadAndMergeConfigurations(ProjectFileBrowser.FilePair filePair) throws IOException {
        return yamlMerger.mergeYamlFiles(filePair.getCommonFile(), filePair.getEnvFile());
    }
}

