package com.jpmchase.datapipeline.coordinator;

import com.jpmchase.datapipeline.coordinator.core.loader.ModelLoader;
import com.jpmchase.datapipeline.coordinator.core.loader.PipelineLoader;
import com.jpmchase.datapipeline.coordinator.core.loader.StageLoader;
import com.jpmchase.datapipeline.coordinator.core.loader.VariablesLoader;
import com.jpmchase.datapipeline.coordinator.model.ExecutionPlan;
import com.jpmchase.datapipeline.coordinator.core.processor.PipelineProcessor;
import com.jpmchase.datapipeline.coordinator.model.PipelineContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoordinatorApplication implements CommandLineRunner {

    private static Logger LOG = LoggerFactory.getLogger(CoordinatorApplication.class);

    public String basePath = "/Users/karthickselvaraj/Documents/cmdline_coordinator/src/main/resources/dataproject";

    @Autowired
    private VariablesLoader variablesLoader;

    @Autowired
    private ModelLoader modelLoader;

    @Autowired
    private StageLoader stageLoader;

    @Autowired
    private PipelineProcessor pipelineProcessor;

    @Autowired
    private PipelineLoader pipelineLoader;

    public static void main(String[] args) {
        LOG.info("STARTING THE APPLICATION");
        SpringApplication.run(CoordinatorApplication.class, args);
        LOG.info("APPLICATION FINISHED");
    }

    @Override
    public void run(String... args) throws Exception {
        PipelineContext pipelineContext = new PipelineContext();
        pipelineContext.setPipelineName("sales_pipeline");
        pipelineContext.setEnvironment("dev");
        pipelineContext.setProjectLocation("/Users/karthickselvaraj/Documents/cmdline_coordinator/src/main/resources/dataproject");
        ExecutionPlan executionPlan = pipelineProcessor.buildExecutionPlan(pipelineContext);
        System.out.println(executionPlan.toString());
    }
}
