package com.jpmchase.datapipeline.coordinator.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Test {
    private String name;
    private String sqlTest; // SQL test query after variable substitution
}

