package com.jpmchase.datapipeline.coordinator.core.loader;

import com.jpmchase.datapipeline.coordinator.core.utils.ProjectFileBrowser;
import com.jpmchase.datapipeline.coordinator.core.utils.YamlMerger;
import com.jpmchase.datapipeline.coordinator.model.PipelineContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Map;

@Component
public class StageLoader extends AbstractConfigLoader<Map<String,Object>>{

    @Override
    protected ProjectFileBrowser.FilePair getFilePair(String stateName, PipelineContext pipelineContext) throws IOException {
        return fileBrowser.getStageFilePair(Paths.get(pipelineContext.getProjectLocation()), stateName, pipelineContext.getEnvironment());
    }

    @Override
    protected Map<String, Object> loadAndMergeConfigurations(ProjectFileBrowser.FilePair filePair) throws IOException {
        return yamlMerger.mergeYamlFiles(filePair.getCommonFile(), filePair.getEnvFile());
    }
}

