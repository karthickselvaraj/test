//package com.jpmchase.datapipeline.coordinator;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.io.IOException;
//import java.util.*;
//
//@Service
//public class PipelineProcessor {
//
//    private final PipelineLoader pipelineLoader;
//    private final StageLoader stageLoader;
//    private final VariablesLoader variablesLoader;
//    private final ModelLoader modelLoader;
//
//    @Autowired
//    public PipelineProcessor(PipelineLoader pipelineLoader, StageLoader stageLoader,
//                             VariablesLoader variablesLoader, ModelLoader modelLoader) {
//        this.pipelineLoader = pipelineLoader;
//        this.stageLoader = stageLoader;
//        this.variablesLoader = variablesLoader;
//        this.modelLoader = modelLoader;
//    }
//
//    public ExecutionPlan buildExecutionPlan(String pipelineName, String environment) throws IOException {
//        // Step 1: Load and merge variables
//        Map<String, Object> variables = variablesLoader.loadVariables(environment);
//        System.out.println("Variables loaded: " + variables);
//
//        // Step 2: Load and merge pipeline configurations
//        Map<String, Object> pipelineData = pipelineLoader.loadPipeline(pipelineName);
//        System.out.println("Pipeline data: " + pipelineData);
//
//        // Extract the pipeline details
//        Map<String, Object> pipeline = (Map<String, Object>) pipelineData.get("pipeline");
//        if (pipeline == null) {
//            throw new RuntimeException("Invalid pipeline configuration: 'pipeline' section is missing.");
//        }
//
//        // Get the list of stages
//        List<String> stageNames = (List<String>) pipeline.get("stages");
//        if (stageNames == null || stageNames.isEmpty()) {
//            throw new RuntimeException("Pipeline '" + pipelineName + "' has no stages defined.");
//        }
//
//        // Prepare the list of ExecutionStages
//        List<ExecutionStage> executionStages = new ArrayList<>();
//
//        int sequenceNumber = 1;
//        for (String stageName : stageNames) {
//            // Step 3: Load and merge stage configurations
//            Map<String, Object> stageData = stageLoader.loadStage(stageName, environment);
//            System.out.println("Stage data for " + stageName + ": " + stageData);
//
//            // Extract stage details
//            Map<String, Object> stageConfig = (Map<String, Object>) stageData.get("stage");
//            if (stageConfig == null) {
//                throw new RuntimeException("Invalid stage configuration for '" + stageName + "': 'stage' section is missing.");
//            }
//
//            // Step 4: Handle stage-specific variables
//            Map<String, Object> stageVariables = (Map<String, Object>) stageConfig.get("variables");
//            if (stageVariables != null) {
//                // Merge stage-specific variables into the variables map
//                variables.putAll(stageVariables);
//            }
//
//            // Step 5: Load the SQL model content
//            String sqlModelName = (String) stageConfig.get("sql_model");
//            String sqlModelContent = null;
//            if (sqlModelName != null) {
//                sqlModelContent = modelLoader.loadModel(
//                        "/Users/karthickselvaraj/Documents/cmdline_coordinator/src/main/resources/dataproject",
//                        sqlModelName, environment);
//            }
//
//            // Step 6: Perform variable substitution
//            String substitutedSql = null;
//            if (sqlModelContent != null) {
//                substitutedSql = VariableReplacer.replaceVariables(sqlModelContent, variables, true);
//            }
//
//            // Step 7: Build the ExecutionStage object
//            ExecutionStage executionStage = new ExecutionStage(sequenceNumber++, stageName);
//
//            // Set basic details
//            executionStage.setDescription((String) stageConfig.get("description"));
//            executionStage.setSourceDatabase(VariableReplacer.replaceVariables((String) stageConfig.get("source_database"), variables, true));
//            executionStage.setTargetDatabase(VariableReplacer.replaceVariables((String) stageConfig.get("target_database"), variables, true));
//            executionStage.setSqlQueryResolved(substitutedSql);
//
//            // Handle output table
//            Map<String, Object> outputTable = (Map<String, Object>) stageConfig.get("output_table");
//            if (outputTable != null) {
//                executionStage.setOutputTable(substituteVariablesInMap(outputTable, variables));
//            }
//
//            // Handle tests
//            List<Map<String, Object>> testsConfig = (List<Map<String, Object>>) stageConfig.get("tests");
//            if (testsConfig != null) {
//                List<Test> tests = new ArrayList<>();
//                for (Map<String, Object> testConfig : testsConfig) {
//                    String testName = (String) testConfig.get("name");
//                    String sqlTest = (String) testConfig.get("sql_test");
//                    String substitutedSqlTest = VariableReplacer.replaceVariables(sqlTest, variables, true);
//                    tests.add(new Test(testName, substitutedSqlTest));
//                }
//                executionStage.setTests(tests);
//            }
//
//            // Handle output variables
//            List<Map<String, Object>> outputVariablesConfig = (List<Map<String, Object>>) stageConfig.get("output_variables");
//            if (outputVariablesConfig != null) {
//                List<OutputVariable> outputVariables = new ArrayList<>();
//                for (Map<String, Object> outputVarConfig : outputVariablesConfig) {
//                    String name = (String) outputVarConfig.get("name");
//                    String description = (String) outputVarConfig.get("description");
//                    String query = (String) outputVarConfig.get("query");
//                    String format = (String) outputVarConfig.get("format");
//                    String substitutedQuery = VariableReplacer.replaceVariables(query, variables, true);
//                    outputVariables.add(new OutputVariable(name, description, substitutedQuery, format));
//                }
//                executionStage.setOutputVariables(outputVariables);
//            }
//
//            // Handle output variable assignments
//            Map<String, String> outputVariableAssignments = (Map<String, String>) stageConfig.get("output_variable_assignment");
//            executionStage.setOutputVariableAssignments(outputVariableAssignments);
//
//            executionStages.add(executionStage);
//        }
//
//        // Step 8: Build the ExecutionPlan
//        ExecutionPlan executionPlan = new ExecutionPlan(variables, executionStages);
//
//        return executionPlan;
//    }
//
//    /**
//     * Performs variable substitution in a map of strings.
//     *
//     * @param inputMap  The map with string values.
//     * @param variables The variables map for substitution.
//     * @return A new map with variables substituted in the values.
//     */
//    private Map<String, Object> substituteVariablesInMap(Map<String, Object> inputMap, Map<String, Object> variables) {
//        Map<String, Object> resultMap = new HashMap<>();
//        for (Map.Entry<String, Object> entry : inputMap.entrySet()) {
//            if (entry.getValue() instanceof String) {
//                String substitutedValue = VariableReplacer.replaceVariables((String) entry.getValue(), variables, true);
//                resultMap.put(entry.getKey(), substitutedValue);
//            } else {
//                resultMap.put(entry.getKey(), entry.getValue());
//            }
//        }
//        return resultMap;
//    }
//}