package com.jpmchase.datapipeline.coordinator.core.utils;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VariableReplacer {

    /**
     * Replaces variable placeholders in the input string with actual values from the variables map.
     *
     * Variable placeholders are in the format {{ var('variable.path') }}.
     *
     * @param input     The input string containing variable placeholders.
     * @param variables The map of variables to use for substitution.
     * @return The input string with variable placeholders replaced with actual values.
     */
    public static String replaceVariables(String input, Map<String, Object> variables, boolean allowUnresolved) {
        if (input == null) {
            return null;
        }

        Pattern pattern = Pattern.compile("\\{\\{\\s*var\\(['\"]([^'\"]+)['\"]\\)\\s*\\}\\}");
        Matcher matcher = pattern.matcher(input);
        StringBuffer sb = new StringBuffer();

        while (matcher.find()) {
            String variablePath = matcher.group(1);
            Object value = resolveVariablePath(variablePath, variables);
            if (value == null) {
                if (allowUnresolved) {
                    // Leave the placeholder as is
                    matcher.appendReplacement(sb, matcher.group(0));
                } else {
                    throw new RuntimeException("Variable '" + variablePath + "' not found in context.");
                }
            } else {
                matcher.appendReplacement(sb, Matcher.quoteReplacement(value.toString()));
            }
        }
        matcher.appendTail(sb);
        return sb.toString();
    }


    /**
     * Resolves a variable value from a nested variables map using a dot-separated path.
     *
     * @param variablePath The dot-separated variable path (e.g., "schema.source_schema").
     * @param variables    The nested variables map.
     * @return The resolved variable value, or null if not found.
     */
    @SuppressWarnings("unchecked")
    private static Object resolveVariablePath(String variablePath, Map<String, Object> variables) {
        String[] parts = variablePath.split("\\.");
        Object currentValue = variables;

        for (String part : parts) {
            if (currentValue instanceof Map) {
                currentValue = ((Map<String, Object>) currentValue).get(part);
                if (currentValue == null) {
                    return null;
                }
            } else {
                return null;
            }
        }

        return currentValue;
    }
}

