-- Clean and enrich sales data

WITH cleaned_data AS (
    SELECT
        order_id,
        order_date,
        product_id,
        quantity,
        price,
        region,
        quantity * price AS total_price
    FROM
        {{ var('schema.source_schema') }}.{{ var('table.raw_sales_table') }}
    WHERE
        order_date BETWEEN '{{ var('filter.start_date') }}' AND '{{ var('filter.end_date') }}'
)

SELECT * FROM cleaned_data;
