-- Aggregate sales data by product and region

WITH sales_data AS (
    SELECT
        order_id,
        product_id,
        total_price,
        region
    FROM
        {{ var('schema.target_schema') }}.{{ var('table.clean_sales_table') }}
)

SELECT
    product_id,
    region,
    SUM(total_price) AS total_sales
FROM
    sales_data
GROUP BY
    product_id,
    region;
