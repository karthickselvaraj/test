package com.jpmchase.datapipeline.coordinator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoordinatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
